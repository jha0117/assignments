package finance.board.vo;

public class BoardCommentVO {

	private int commentNo;
	private String commentContent;
	private String commentUserId;
	private String commentDate;
	private int BoardNo;
	
	public BoardCommentVO() {
	}

	public BoardCommentVO(int commentNo, String commentContent,
			String commentUserId, String commentDate, int boardNo) {
		super();
		this.commentNo = commentNo;
		this.commentContent = commentContent;
		this.commentUserId = commentUserId;
		this.commentDate = commentDate;
		BoardNo = boardNo;
	}

	public int getCommentNo() {
		return commentNo;
	}

	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}

	public String getCommentContent() {
		return commentContent;
	}

	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}

	public String getCommentUserId() {
		return commentUserId;
	}

	public void setCommentUserId(String commentUserId) {
		this.commentUserId = commentUserId;
	}

	public String getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}

	public int getBoardNo() {
		return BoardNo;
	}

	public void setBoardNo(int boardNo) {
		BoardNo = boardNo;
	}

	@Override
	public String toString() {
		return "BoardComment [commentNo=" + commentNo + ", commentContent="
				+ commentContent + ", commentUserId=" + commentUserId
				+ ", commentDate=" + commentDate + ", BoardNo=" + BoardNo + "]";
	}
	
}

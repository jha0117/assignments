package finance.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import finance.board.util.JDBCUtils;
import finance.board.vo.BoardCommentVO;

public class BoardCommentDAO {

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	public ArrayList<BoardCommentVO> getCommentList(int boardNo){
		ArrayList<BoardCommentVO> commentList = new ArrayList<BoardCommentVO>();
		
		conn = JDBCUtils.getConnection();
		String sql = "SELECT COMMENTNO, COMMENTCONTENT, COMMENTUSERID, TO_CHAR(COMMENTDATE, 'YYYY-MM-DD hh:mm:ss'), BOARDNO "
				+ "FROM BOARDCOMMENT WHERE BOARDNO = ? ORDER BY COMMENTNO";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
			while(rs.next()){
				BoardCommentVO comment = new BoardCommentVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5));
				commentList.add(comment);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		
		
		return commentList;
	}
	
}

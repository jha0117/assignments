package finance.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import finance.board.util.JDBCUtils;
import finance.board.vo.BoardVO;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	public ArrayList<BoardVO> getBoardList(){
		ArrayList<BoardVO> list = new ArrayList<BoardVO>();
		conn = JDBCUtils.getConnection();
		String sql = "SELECT BOARDNO, BOARDTITLE, BOARDCONTENT, BOARDUSERID, TO_CHAR(BOARDDATE, 'YYYY-MM-DD hh:mm:ss') "
				+ "FROM BOARD ORDER BY BOARDNO DESC";
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				BoardVO board = new BoardVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				list.add(board);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		
		return list;
	}

	public BoardVO getBoard(int boardNo) {
		BoardVO board = null;
		
		conn = JDBCUtils.getConnection();
		String sql = "SELECT BOARDNO, BOARDTITLE, BOARDCONTENT, BOARDUSERID, TO_CHAR(BOARDDATE, 'YYYY-MM-DD hh:mm:ss') "
				+ "FROM BOARD WHERE BOARDNO = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			rs = ps.executeQuery();
			while(rs.next()){
				board = new BoardVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		
		return board;
	}

	public int deleteBoard(int boardNo) {
		int result = 0;
		
		conn = JDBCUtils.getConnection();
		String sql = "DELETE FROM BOARD WHERE BOARDNO = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, boardNo);
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
		
		return result;
	}

	public int updateBoard(BoardVO board) {
		int result = 0;
		
		conn = JDBCUtils.getConnection();
		String sql = "UPDATE BOARD SET BOARDTITLE = ?, BOARDCONTENT = ?, BOARDDATE = SYSDATE "
				+ "WHERE BOARDNO = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getBoardTitle());
			ps.setString(2, board.getBoardContent());
			ps.setInt(3, board.getBoardNo());
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
		
		return result;
	}

	public int insertBoard(BoardVO board) {
		int result = 0;
		
		conn = JDBCUtils.getConnection();
		String sql = "INSERT INTO BOARD VALUES("
				+ "(SELECT NVL(MAX(BOARDNO)+1 , 0) FROM BOARD), ?, ?, ?, SYSDATE)";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, board.getBoardTitle());
			ps.setString(2, board.getBoardContent());
			ps.setString(3, board.getBoardUserId());
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
		
		return result;
	}
	
}

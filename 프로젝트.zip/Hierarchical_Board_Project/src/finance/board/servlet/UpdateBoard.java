package finance.board.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import finance.board.dao.BoardDAO;
import finance.board.vo.BoardVO;

/**
 * Servlet implementation class DeleteBoard
 */
@WebServlet("/updateBoard.do")
public class UpdateBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		String boardUserId = request.getParameter("boardUserId");
		String boardTitle = request.getParameter("boardTitle");
		String boardContent = request.getParameter("boardContent");
		
		BoardVO board = new BoardVO(boardNo, boardTitle, boardContent, boardUserId, null);		
		
		System.out.println(board);
		
		BoardDAO dao = new BoardDAO();
		int result = dao.updateBoard(board);
		
		response.sendRedirect("getBoardList.do");
		return;
	}

}

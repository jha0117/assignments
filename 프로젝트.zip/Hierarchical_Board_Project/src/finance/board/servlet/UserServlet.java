package finance.board.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import finance.board.dao.UserDAO;
import finance.board.vo.UserVO;

@WebServlet("/user.do")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDAO userDao = UserDAO.getinstance();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String action = request.getParameter("action");
		String content = null;

		if (action.equals("login")) {
			content = login(request, response);
		}else if (action.equals("logout")) {
			content = logout(request, response);
		}else if (action.equals("goToRegisterPage")){
			request.setAttribute("content", "register.jsp");
			content = "menu.jsp";
		}else if (action.equals("register")){
			content = register(request, response);
		}else if (action.equals("toGoUpdatePage")) {
			request.setAttribute("content", "update.jsp");
			content = "menu.jsp";
		}else if (action.equals("updateUser")){
			content = updateUser(request, response);
		}else if (action.equals("deleteUser")){
			content = deleteUser(request, response);
		}
		request.getRequestDispatcher(content).forward(request, response);
	}

	private String login(HttpServletRequest request,
			HttpServletResponse response) {
		String content = "";
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		try {
			boolean flag= userDao.login(userid, password);
			if (flag) {
				HttpSession s = request.getSession();
				UserVO user = new UserVO();
				user = userDao.selectUser(userid);
				s.setAttribute("User", user);
				content = "/getBoardList.do"; 
			}else{
				request.setAttribute("msg", "아이디 또는 비밀번호가 틀렸습니다. 다시 한 번 확인해주세요.");
				request.setAttribute("content", "Error.jsp");
				return "menu.jsp";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return content;
	}
	
	private String logout(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession s = request.getSession(false);
		if (s != null) {
			s.invalidate();
		}
		request.setAttribute("content", "login.jsp");
		return "menu.jsp";
	}

	private String register(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			String userid = request.getParameter("userid").trim();
			String password = request.getParameter("password").trim();
			String name = request.getParameter("name").trim();
			String email = request.getParameter("email").trim();
			UserVO user = new UserVO(userid, password, name, email);
			userDao.insertUser(user);
			request.setAttribute("content", "login.jsp");
		} catch (Exception e) {
			e.printStackTrace();
//			request.setAttribute("content", "/Error.jsp");
		}
		return "menu.jsp";
	}
	
	private String updateUser(HttpServletRequest request,
			HttpServletResponse response) {
		String userid = request.getParameter("userid").trim();
		String password = request.getParameter("password").trim();
		String name = request.getParameter("name").trim();
		String email = request.getParameter("email").trim();
		UserVO user = new UserVO(userid, password, name, email);
		try {
			userDao.updateUser(user);
			HttpSession s = request.getSession();
			s.setAttribute("User", user);
			request.setAttribute("content", "update.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
//			request.setAttribute("content", "/Error.jsp");
		}
		return "menu.jsp";
	}

	private String deleteUser(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession s = request.getSession();
		UserVO user = (UserVO) s.getAttribute("User");
		try {
			userDao.deleteUser(user);
			request.setAttribute("content", "login.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
//			request.setAttribute("content", "/Error.jsp");
		}
		return "menu.jsp";
	}	
}
